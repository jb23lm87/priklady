#! /bin/bash
echo "What is your name?"
#-r If this option is given, backslash does not act as an escape character.
read  -r NAME
echo "Hello $NAME"
