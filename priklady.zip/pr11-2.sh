#!/bin/bash
#spustiť s argumentom
echo "You have entered: $1"
