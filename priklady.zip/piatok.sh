#!/bin/bash
for ((a = 1; a < 10; a++)); do
    echo $a x povedane
done
