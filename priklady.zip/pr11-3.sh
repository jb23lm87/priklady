#!/bin/bash
clear
echo "The name of this process is $0"
echo "You have passed $# parameters. They are:$*" 
echo "First is $1" 
echo
